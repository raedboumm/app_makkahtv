import './Logo.css';

export default function Logo({ height = 48, className = '' }) {
  return (
    <img
      src={`${import.meta.env.BASE_URL}assets/logo.png`}
      alt="أوقاف محمد محمد خوجه كوجك"
      className={`logo ${className}`}
      style={{ height }}
    />
  );
}
