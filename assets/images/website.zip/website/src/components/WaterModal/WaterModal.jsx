import { useState } from 'react';
import { Droplets, X, Check, Heart, Send } from 'lucide-react';
import './WaterModal.css';

const EMPTY_FORM = {
  name: '', phone: '', entityType: '', entityName: '',
  city: '', qty: '', frequency: '', notes: '',
};

export default function WaterModal({ open, onClose }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitted, setSubmitted] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleClose = () => {
    setSubmitted(false);
    setForm(EMPTY_FORM);
    onClose();
  };

  if (!open) return null;

  return (
    <>
      <div className="wm-overlay" onClick={handleClose} />

      <div className="wm">
        {/* Header */}
        <div className="wm__header">
          <div className="wm__title-row">
            <div className="wm__icon"><Droplets size={20} /></div>
            <div>
              <h3 className="wm__title">طلب تزويد بالماء</h3>
              <p className="wm__subtitle">أوقاف محمد بن محمد خوجه كوجك</p>
            </div>
          </div>
          <button className="wm__close" onClick={handleClose} aria-label="إغلاق">
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="wm__body">
          {submitted ? (
            <div className="wm__success">
              <div className="wm__success-icon"><Check size={32} /></div>
              <h3>تم استلام طلبك!</h3>
              <p>شكراً لك. سيقوم فريقنا بمراجعة طلبك والتواصل معك خلال 48 ساعة عمل.</p>
              <button className="btn btn--gold btn--md" onClick={handleClose}>إغلاق</button>
            </div>
          ) : (
            <form onSubmit={e => { e.preventDefault(); setSubmitted(true); }}>

              <div className="wm__notice">
                <Heart size={14} />
                <span>هذه الخدمة مقدمة بصفة خيرية من أوقاف خوجه كوجك</span>
              </div>

              <div className="wm__row">
                <div className="wm__field">
                  <label>اسم مقدم الطلب <span className="wm__req">*</span></label>
                  <input required value={form.name} onChange={e => set('name', e.target.value)} placeholder="الاسم الكامل" />
                </div>
                <div className="wm__field">
                  <label>رقم الجوال <span className="wm__req">*</span></label>
                  <input required value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="05XXXXXXXX" dir="ltr" />
                </div>
              </div>

              <div className="wm__field">
                <label>نوع الجهة <span className="wm__req">*</span></label>
                <select required value={form.entityType} onChange={e => set('entityType', e.target.value)}>
                  <option value="">اختر...</option>
                  <option>مسجد</option>
                  <option>مدرسة</option>
                  <option>جمعية خيرية</option>
                  <option>مستشفى / مركز صحي</option>
                  <option>جهة حكومية</option>
                  <option>أفراد / عائلة</option>
                  <option>أخرى</option>
                </select>
              </div>

              <div className="wm__row">
                <div className="wm__field">
                  <label>اسم الجهة / المسجد</label>
                  <input value={form.entityName} onChange={e => set('entityName', e.target.value)} placeholder="اسم الجهة" />
                </div>
                <div className="wm__field">
                  <label>المدينة <span className="wm__req">*</span></label>
                  <input required value={form.city} onChange={e => set('city', e.target.value)} placeholder="مكة، جدة، الرياض..." />
                </div>
              </div>

              <div className="wm__row">
                <div className="wm__field">
                  <label>الكمية المطلوبة <span className="wm__req">*</span></label>
                  <input required value={form.qty} onChange={e => set('qty', e.target.value)} placeholder="عدد الكراتين / العبوات" />
                </div>
                <div className="wm__field">
                  <label>التكرار</label>
                  <select value={form.frequency} onChange={e => set('frequency', e.target.value)}>
                    <option value="">اختر...</option>
                    <option>أسبوعي</option>
                    <option>نصف شهري</option>
                    <option>شهري</option>
                    <option>لمرة واحدة</option>
                  </select>
                </div>
              </div>

              <div className="wm__field">
                <label>ملاحظات إضافية</label>
                <textarea
                  value={form.notes}
                  onChange={e => set('notes', e.target.value)}
                  rows={3}
                  placeholder="أي تفاصيل إضافية عن الطلب أو موعد التسليم المفضل..."
                />
              </div>

              <button type="submit" className="wm__submit">
                <Send size={16} />
                إرسال الطلب
              </button>
            </form>
          )}
        </div>
      </div>
    </>
  );
}
