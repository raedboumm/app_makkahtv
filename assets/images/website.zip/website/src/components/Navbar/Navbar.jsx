import { useState } from 'react';
import { Droplets, BarChart3, Menu, X } from 'lucide-react';
import Logo from '../Logo/Logo';
import useScrollY from '../../hooks/useScrollY';
import './Navbar.css';

const LINKS = [
  { label: 'الرئيسية', href: '#home'     },
  { label: 'عن الوقف',  href: '#about'    },
  { label: 'منتجاتنا', href: '#products' },
  { label: 'الجودة',   href: '#quality'  },
  { label: 'تواصل',    href: '#contact'  },
];

export default function Navbar({ onWaterRequest }) {
  const scrollY = useScrollY();
  const [open, setOpen] = useState(false);
  const scrolled = scrollY > 60;

  return (
    <header className={`navbar navbar--scrolled ${scrolled ? ' navbar--scrolled' : ''}`}>
      <div className="navbar__inner">

        <Logo height={scrolled ? 42 : 48} />

        {/* Desktop nav */}
        <nav className="navbar__nav">
          {LINKS.map(l => (
            <a
              key={l.href}
              href={l.href}
              className={`navbar__link navbar__link--dark ${scrolled ? ' navbar__link--dark' : ' navbar__link--light'}`}
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* Desktop CTAs */}
        <div className="navbar__actions">
          <button
            onClick={onWaterRequest}
            className="btn btn--gold btn--sm"
          >
            <Droplets size={15} />
            طلب تزويد بالماء
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          className={`navbar__toggle navbar__toggle--dark${scrolled ? ' navbar__toggle--dark' : ' navbar__toggle--light'}`}
          onClick={() => setOpen(!open)}
          aria-label="القائمة"
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="navbar__mobile">
          {LINKS.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="navbar__mobile-link"
              onClick={() => setOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <div style={{ height: 1, background: 'rgba(26,35,50,0.10)', margin: '0.5rem 0' }} />
          <a href="/wakf/dashboard/" className="navbar__mobile-link" onClick={() => setOpen(false)}>
            <BarChart3 size={14} style={{ display: 'inline', verticalAlign: 'middle', marginLeft: '6px' }} />
            لوحة التحكم
          </a>
          <button
            onClick={() => { onWaterRequest(); setOpen(false); }}
            className="btn btn--gold btn--full"
            style={{ borderRadius: '0.75rem', padding: '0.75rem 1rem', marginTop: '0.5rem' }}
          >
            <Droplets size={15} />
            طلب تزويد بالماء
          </button>
        </div>
      )}
    </header>
  );
}
