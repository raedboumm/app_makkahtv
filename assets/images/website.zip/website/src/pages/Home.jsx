import { useState } from 'react';
import Navbar from '../components/Navbar/Navbar';
import WaterModal from '../components/WaterModal/WaterModal';
import Hero from '../sections/Hero/Hero';
import StatsBar from '../sections/StatsBar/StatsBar';
import About from '../sections/About/About';
import Products from '../sections/Products/Products';
import Quality from '../sections/Quality/Quality';
import OrderSection from '../sections/OrderSection/OrderSection';
import Contact from '../sections/Contact/Contact';
import Footer from '../sections/Footer/Footer';

export default function Home() {
  const [modalOpen, setModalOpen] = useState(false);
  const openModal = () => setModalOpen(true);

  return (
    <>
      <WaterModal open={modalOpen} onClose={() => setModalOpen(false)} />
      <Navbar onWaterRequest={openModal} />
      <main>
        <Hero />
        <StatsBar />
        <About />
        <Products />
        <Quality />
        <OrderSection onWaterRequest={openModal} />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
