import { BarChart3, Factory, Truck } from 'lucide-react';
import Logo from '../../components/Logo/Logo';
import './Footer.css';

const LINKS = [
  { Icon: BarChart3, label: 'لوحة التحكم', href: '/wakf/dashboard/' },
  { Icon: Factory,   label: 'نظام ERP',    href: '/wakf/erp/'       },
  { Icon: Truck,     label: 'التوزيع',     href: '/wakf/distribution/' },
];

export default function Footer() {
  return (
      <footer className="footer">
      <div className="footer__inner">

        <div className='bglogo'><Logo height={44} /></div>

        <div className="footer__copy">
          <p className="footer__brand">أوقاف محمد محمد خوجه كوجك</p>
          <p className="footer__year">
            جميع الحقوق محفوظة © {new Date().getFullYear()} — أوقاف خوجه كوجك
          </p>
        </div>

        <div className="footer__links">
          {LINKS.map(({ Icon, label, href }) => (
            <a key={href} href={href} className="footer__link">
              <Icon size={13} />
              {label}
            </a>
          ))}
        </div>

      </div>
    </footer>
  );
}
