import { Droplets, Zap, ShieldCheck, FlaskConical, Award, ArrowLeft } from 'lucide-react';
import './Quality.css';

const STEPS = [
  { num: '1', title: 'مصدر المياه',     desc: 'مياه جوفية مختارة تخضع لفحص دوري مستمر',                     Icon: Droplets,     color: '#1B9E8E' },
  { num: '2', title: 'معالجة RO',       desc: 'تصفية عكسية متعددة المراحل لإزالة الشوائب',                   Icon: Zap,          color: '#C8972B' },
  { num: '3', title: 'تعقيم بالأوزون', desc: 'حقن الأوزون والأشعة فوق البنفسجية للقضاء على البكتيريا',       Icon: ShieldCheck,  color: '#1A2332' },
  { num: '4', title: 'فحص المختبر',    desc: 'تحاليل شاملة قبل الإفراج وفق معايير WHO وSFDA',               Icon: FlaskConical, color: '#8b5cf6' },
];

const CERTS = [
  'ISO 22000:2018',
  'FSSC 22000',
  'HACCP',
  'هيئة الغذاء والدواء (SFDA)',
  'سياسة حلال',
];

export default function Quality() {
  return (
    <section id="quality" className="quality">
      <div className="section-container">

        <div className="section-header">
          <div className="section-badge section-badge--teal">
            <ShieldCheck size={14} />
            معايير الجودة
          </div>
          <h2 className="section-title">نظام الجودة والسلامة</h2>
          <p className="section-desc">كل قطرة تمر بأربع مراحل صارمة قبل وصولها إليك</p>
        </div>

        {/* Process steps */}
        <div className="quality__steps">
          {STEPS.map(({ num, title, desc, Icon, color }, i) => (
            <div key={i} className="quality__step-wrap">
              <div className="quality__step" style={{ '--sc': color }}>
                <div className="quality__step-head">
                  <div className="quality__step-icon"><Icon size={18} /></div>
                  <span className="quality__step-num">المرحلة {num}</span>
                </div>
                <h3 className="quality__step-title">{title}</h3>
                <p className="quality__step-desc">{desc}</p>
              </div>
              {i < STEPS.length - 1 && (
                <div className="quality__arrow" aria-hidden="true">
                  <ArrowLeft size={16} />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Certifications */}
        <div className="quality__certs">
          <h3 className="quality__certs-title">شهاداتنا المعتمدة</h3>
          <div className="quality__certs-list">
            {CERTS.map((c, i) => (
              <span key={i} className="quality__cert">
                <Award size={14} />
                {c}
              </span>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
