import { Landmark, Building2, Calendar, Clock, Heart } from 'lucide-react';
import './About.css';

const WAQF_STATS = [
  { Icon: Calendar, label: 'سنة التأسيس', val: '1163هـ',     color: 'var(--gold)'  },
  { Icon: Clock,    label: 'عمر الوقف',   val: '275+ عاماً', color: 'var(--teal)'  },
  { Icon: Heart,    label: 'طابع الوقف',  val: 'خيري',        color: '#ef4444' },
];

const FACTORY_DETAILS = [
  { label: 'الموقع',            val: 'جبيل الصناعية'     },
  { label: 'خطوط الإنتاج',     val: '3 خطوط متكاملة'    },
  { label: 'الطاقة الإنتاجية', val: '20,000 عبوة / يوم' },
  { label: 'نظام المعالجة',    val: 'RO + UV + أوزون'    },
];

export default function About() {
  return (
    <section id="about" className="about">
      <div className="section-container">

        {/* Title */}
        <div className="section-header">
          <div className="section-badge section-badge--gold">
            <Landmark size={14} />
            تعريف بالوقف والمصنع
          </div>
          <h2 className="section-title">أوقاف محمد بن محمد خوجه كوجك</h2>
          <p className="section-desc">
            وقف خيري عريق يجمع بين الإرث الإسلامي العميق والصناعة الحديثة لخدمة أهل مكة المكرمة والمجتمع
          </p>
        </div>

        <div className="about__grid">

          {/* ── Waqf card ── */}
          <div className="about__card about__card--gold">
            <div className="about__card-head">
              <div className="about__card-icon" style={{ background: 'rgba(200,151,43,0.12)', color: 'var(--gold)' }}>
                <Landmark size={22} />
              </div>
              <div>
                <h3 className="about__card-title">تعريف بالوقف</h3>
                <p className="about__card-sub">الوقف الخيري العريق</p>
              </div>
            </div>

            <p className="about__text">
              يُعدّ وقف أوقاف محمد بن محمد خوجه كوجك من أبرز الأوقاف القائمة بمكة المكرمة، وقد أُنشئ عام{' '}
              <strong className="about__hl-gold">1163هـ</strong>، أي منذ ما يقارب{' '}
              <strong className="about__hl-gold">275 عاماً</strong>. يهدف الوقف إلى جعل جزء كبير من إيراداته{' '}
              <strong>سبيل ماء</strong> لأهل مكة المكرمة.
            </p>
            <p className="about__text about__text--muted">
              بدأ الوقف في أصله بئراً بجوار بيت الله الحرام مع مجموعة من الخادمين لتقديم الخدمة لقاصدي البئر، إضافة إلى مجموعة من المساكن الشعبية التي تُؤجَّر ويُصرَف دخلها على صيانة البئر وأجور العاملين.
            </p>
            <p className="about__text about__text--muted">
              مع توسعة الحرم المكي الشريف، تطورت الأنشطة بشكل كبير حتى باتت تشمل توزيع المياه عبر صهاريج كبيرة وعبوات صحة الماء التي تنتشر اليوم في كثير من المساجد والقطاعات الخدمية والحكومية.
            </p>

            <div className="about__waqf-stats">
              {WAQF_STATS.map(({ Icon, label, val, color }, i) => (
                <div key={i} className="about__stat" style={{ '--sc': color }}>
                  <Icon size={18} />
                  <p className="about__stat-val">{val}</p>
                  <p className="about__stat-label">{label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ── Factory card ── */}
          <div className="about__card about__card--teal">
            <div className="about__card-head">
              <div className="about__card-icon" style={{ background: 'rgba(27,158,142,0.12)', color: 'var(--teal)' }}>
                <Building2 size={22} />
              </div>
              <div>
                <h3 className="about__card-title">تعريف بالمصنع</h3>
                <p className="about__card-sub">مصنع مياه الوقف — جبيل الصناعية</p>
              </div>
            </div>

            <p className="about__text">
              استجابةً للتطور وزيادة الطلب، طوّر الوقف منظومته ليُنشئ <strong>مصنع مياه الوقف</strong> في{' '}
              <strong className="about__hl-teal">جبيل الصناعية</strong>، المنطقة الشرقية. يعتمد المصنع على أحدث تقنيات المعالجة لإنتاج مياه شرب نقية.
            </p>
            <p className="about__text about__text--muted">
              يُزوِّد المصنع المساجد والمدارس والجمعيات الخيرية وذوي الاحتياج بالمياه المعبأة سبيلاً خيرياً، كما يخدم القطاعات التجارية والحكومية وفق معايير جودة صارمة معتمدة دولياً.
            </p>

            <div className="about__factory-grid">
              {FACTORY_DETAILS.map((item, i) => (
                <div key={i} className="about__factory-item">
                  <p className="about__factory-label">{item.label}</p>
                  <p className="about__factory-val">{item.val}</p>
                </div>
              ))}
            </div>

            <div className="about__certs-strip">
              <p className="about__certs-label">الشهادات الدولية المعتمدة</p>
              <p className="about__certs-val">ISO 22000 · FSSC 22000 · HACCP · SFDA</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
