import { Calendar, Heart, Package, ShieldCheck } from 'lucide-react';
import './StatsBar.css';

const STATS = [
  { value: '10+', label: 'سنوات من الخبرة',  Icon: Calendar   },
  { value: '28+', label: 'جهة مستفيدة',       Icon: Heart      },
  { value: '3',   label: 'أحجام منتجات',      Icon: Package    },
  { value: '98%', label: 'معدل جودة المنتج',  Icon: ShieldCheck },
];

export default function StatsBar() {
  return (
    <section className="statsbar">
      <div className="statsbar__grid">
        {STATS.map(({ value, label, Icon }, i) => (
          <div key={i} className="statsbar__item">
            <Icon size={16} className="statsbar__icon" />
            <p className="statsbar__value">{value}</p>
            <p className="statsbar__label">{label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
