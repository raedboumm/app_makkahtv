import { Phone, Mail, MapPin } from 'lucide-react';
import './Contact.css';

const CONTACTS = [
  { Icon: Phone,  label: 'الهاتف',  val: '+966 XX XXX XXXX' },
  { Icon: Mail,   label: 'البريد',  val: 'info@akoya-koshak.sa' },
  { Icon: MapPin, label: 'العنوان', val: 'جبيل الصناعية، المنطقة الشرقية، المملكة العربية السعودية' },
];

export default function Contact() {
  return (
    <section id="contact" className="contact">
      <div className="section-container">

        <div className="section-header">
          <div className="section-badge section-badge--gold">
            <Phone size={14} />
            اتصل بنا
          </div>
          <h2 className="section-title">تواصل معنا</h2>
        </div>

        <div className="contact__grid">
          {CONTACTS.map(({ Icon, label, val }, i) => (
            <div key={i} className="contact__card">
              <div className="contact__icon">
                <Icon size={22} />
              </div>
              <p className="contact__label">{label}</p>
              <p className="contact__val"><span dir="ltr">{val}</span></p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
