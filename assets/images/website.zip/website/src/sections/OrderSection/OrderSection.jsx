import { Droplets, ChevronLeft, Landmark, Heart, Building2, GraduationCap, Hospital, Users } from 'lucide-react';
import './OrderSection.css';

const BENEFICIARIES = [
  { Icon: Landmark,      label: 'مساجد'          },
  { Icon: GraduationCap, label: 'مدارس'          },
  { Icon: Heart,         label: 'جمعيات خيرية'  },
  { Icon: Hospital,      label: 'مستشفيات'       },
  { Icon: Users,         label: 'أفراد وعائلات' },
];

export default function OrderSection({ onWaterRequest }) {
  return (
    <section className="order">

      {/* ── atmospheric blobs ── */}
      <div className="order__blobs" aria-hidden="true">
        <div className="order__blob order__blob--teal" />
        <div className="order__blob order__blob--gold" />
      </div>

      {/* ── top gold hairline ── */}
      <div className="order__hairline" aria-hidden="true" />

      <div className="section-container order__inner">

        {/* ── Icon + badge ── */}
        <div className="order__icon-wrap">
          <Droplets size={36} />
        </div>

        <span className="order__badge">✶ خدمة خيرية مجانية — سبيلاً لوجه الله</span>

        <h2 className="order__title">هل تحتاج إلى تزويد بالماء؟</h2>

        <p className="order__desc">
          مياه الوقف تصل إليك أينما كنت — نخدم الجميع دون مقابل
        </p>

        {/* ── Beneficiary chips ── */}
        <div className="order__chips">
          {BENEFICIARIES.map(({ Icon, label }) => (
            <div key={label} className="order__chip">
              <Icon size={15} />
              <span>{label}</span>
            </div>
          ))}
        </div>

        {/* ── Main CTA ── */}
        <button className="order__cta" onClick={onWaterRequest}>
          <Droplets size={22} />
          <span>اطلب تزويدك بالماء الآن</span>
          <ChevronLeft size={18} className="order__cta-arrow" />
        </button>

      </div>
    </section>
  );
}
