﻿import { Droplets, Package, Check, Star } from 'lucide-react';
import './Products.css';

const PRODUCTS = [
  {
    size: '200 مل',
    type: 'كوب',
    color: '#1B9E8E',
    uses: ['فنادق', 'مؤتمرات', 'طيران'],
    Icon: Droplets,
  },
  {
    size: '330 مل',
    type: 'بلاستيك',
    color: '#C8972B',
    uses: ['بيع للأفراد', 'مكاتب', 'مدارس'],
    Icon: Droplets,
    featured: true,
  },
 
  {
    size: '500 لتر',
    type: 'بلاستيك',
    color: '#8b5cf6',
    uses: ['مستودعات', 'مصانع', 'مشاريع كبيرة'],
    Icon: Package,
  },
];

export default function Products() {
  return (
    <section id="products" className="products">
      <div className="section-container">

        <div className="section-header">
          <div className="section-badge section-badge--gold">
            <Package size={14} />
            تشكيلة منتجاتنا
          </div>
          <h2 className="section-title">منتجاتنا</h2>
          <p className="section-desc">أربعة أحجام تلبي كل احتياجاتك</p>
        </div>

        <div className="products__grid">
          {PRODUCTS.map(({ size, type, color, uses, Icon, featured }, i) => (
            <div
              key={i}
              className={`product-card${featured ? ' product-card--featured' : ''}`}
              style={{
                borderColor: featured ? '#C8972B' : '#f3f4f6',
                boxShadow: featured
                  ? `0 8px 32px ${color}20`
                  : '0 2px 8px rgba(0,0,0,0.04)',
              }}
            >
              {featured && (
                <div className="product-card__badge">
                  <Star size={10} />
                  الأكثر طلباً
                </div>
              )}

              <div
                className="product-card__body"
                style={{ background: `linear-gradient(160deg, ${color}08 0%, transparent 60%)` }}
              >
                <div
                  className="product-card__icon"
                  style={{ backgroundColor: `${color}12`, color }}
                >
                  <Icon size={36} />
                </div>

                <p className="product-card__size" style={{ color }}>{size}</p>
                <p className="product-card__type">{type}</p>

                <ul className="product-card__uses">
                  {uses.map((u, j) => (
                    <li key={j}>
                      <Check size={14} style={{ color }} />
                      {u}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="product-card__footer">
                <a
                  href="#contact"
                  className="product-card__cta"
                  style={
                    featured
                      ? { backgroundColor: '#C8972B', color: '#fff' }
                      : { backgroundColor: `${color}12`, color }
                  }
                >
                  طلب عرض سعر
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
