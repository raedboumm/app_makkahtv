import { ShieldCheck, Package, Landmark, ChevronDown } from 'lucide-react';
import './Hero.css';

export default function Hero() {
  return (
    <section id="home" className="hero">

      {/* ── BG layer 1: dot grid (no overflow clip) ── */}
      <div className="hero__dot-grid" aria-hidden="true" />

      {/* ── BG layer 2: glows + geometry (clipped) ── */}
      <div className="hero__glow-layer" aria-hidden="true">
        <div className="hero__glow hero__glow--center" />
        <div className="hero__glow hero__glow--teal" />
        <div className="hero__glow hero__glow--gold" />
        <div className="hero__ring hero__ring--outer" />
        <div className="hero__ring hero__ring--inner" />
        <div className="hero__top-line" />
        <div className="hero__vignette" />
      </div>

      {/* ── BG layer 3: floating water bubbles ── */}
      <div className="hero__bubbles" aria-hidden="true">
        <span className="hero__bubble hero__bubble--1" />
        <span className="hero__bubble hero__bubble--2" />
        <span className="hero__bubble hero__bubble--3" />
        <span className="hero__bubble hero__bubble--4" />
        <span className="hero__bubble hero__bubble--5" />
        <span className="hero__bubble hero__bubble--6" />
        <span className="hero__bubble hero__bubble--7" />
        <span className="hero__bubble hero__bubble--8" />
        <span className="hero__bubble hero__bubble--9" />
        <span className="hero__bubble hero__bubble--10" />
      </div>

      {/* ── Content ── */}
      <div className="hero__content">

        <div className="hero__badge">
          <Landmark size={12} />
          <span>أوقاف محمد بن محمد خوجه كوجك — منذ 1163 هـ</span>
        </div>

        <h1 className="hero__title">
          ماء طاهر نقي
          <br />
          <span className="hero__title-gradient">من خير الأوقاف</span>
        </h1>

        <div className="hero__divider" aria-hidden="true">
          <div className="hero__divider-line hero__divider-line--r" />
          <div className="hero__divider-dot" />
          <div className="hero__divider-line hero__divider-line--l" />
        </div>

        <p className="hero__desc">
          مياه معبأة بأعلى معايير الجودة العالمية <br /> 
        </p>

         

        <div className="hero__ctas">
          <a href="#products" className="hero__cta-primary">
            <Package size={18} />
            اكتشف منتجاتنا
          </a>
          <a href="#about" className="hero__cta-secondary">
            عن الوقف
          </a>
        </div>
      </div>

      {/* ── Scroll indicator — cascading chevrons ── */}
      <a href="#about" className="hero__scroll" aria-label="استكشف المزيد">
        <span className="hero__scroll-label">استكشف</span>
        <ChevronDown size={20} className="chev chev--1" />
        <ChevronDown size={20} className="chev chev--2" style={{ marginTop: '-10px' }} />
        <ChevronDown size={20} className="chev chev--3" style={{ marginTop: '-10px' }} />
      </a>

    </section>
  );
}
