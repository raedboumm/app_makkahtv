﻿/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  Droplets, ShieldCheck, Award, Truck, Phone, Mail, MapPin,
  ChevronDown, Menu, X, ArrowLeft, Check, Leaf, Zap,
  BarChart3, Factory, FlaskConical, Star, ExternalLink,
  Globe, Users, Package, Heart, Calendar, Building2,
  Landmark, Send, ChevronRight, Clock
} from 'lucide-react';
import Logo from '../../components/common/Logo';

const C = {
  gold:   '#C8972B',
  teal:   '#1B9E8E',
  navy:   '#1A2332',
  cream:  '#F8F5EF',
  dark:   '#0d1520',
};

/* ─── Scroll-aware hook ─── */
function useScrollY() {
  const [y, setY] = useState(0);
  useEffect(() => {
    const fn = () => setY(window.scrollY);
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);
  return y;
}

/* ════════════════════════════════════════
   NAVBAR
════════════════════════════════════════ */
function Navbar({ onWaterRequest }) {
  const scrollY = useScrollY();
  const [open, setOpen] = useState(false);
  const scrolled = scrollY > 60;

  const links = [
    { label: 'الرئيسية', href: '#home'     },
    { label: 'عن الوقف',  href: '#about'    },
    { label: 'منتجاتنا', href: '#products' },
    { label: 'الجودة',   href: '#quality'  },
    { label: 'تواصل',    href: '#contact'  },
  ];

  return (
    <header
      className="fixed top-0 right-0 left-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? 'rgba(255,255,255,0.97)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(200,151,43,0.12)' : 'none',
        boxShadow: scrolled ? '0 2px 24px rgba(26,35,50,0.06)' : 'none',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Logo height={scrolled ? 42 : 48} className="transition-all duration-300" />

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {links.map(l => (
            <a key={l.href} href={l.href}
              className="px-4 py-2 rounded-xl text-sm font-semibold transition-all"
              style={{ color: scrolled ? C.navy : 'white' }}
              onMouseEnter={e => e.currentTarget.style.backgroundColor = scrolled ? `${C.gold}12` : 'rgba(255,255,255,0.1)'}
              onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}>
              {l.label}
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-2">
          <button onClick={onWaterRequest}
            className="flex items-center gap-2 text-white text-sm font-bold px-4 py-2 rounded-xl hover:opacity-90 transition-all"
            style={{ backgroundColor: C.gold }}>
            <Droplets size={15} />طلب تزويد بالماء
          </button>
          <Link to="/dashboard"
            className="flex items-center gap-2 text-sm font-bold px-4 py-2 rounded-xl border hover:opacity-90 transition-all"
            style={{ color: scrolled ? C.navy : 'white', borderColor: scrolled ? `${C.navy}30` : 'rgba(255,255,255,0.3)' }}>
            <BarChart3 size={15} />لوحة التحكم
          </Link>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden w-9 h-9 rounded-xl flex items-center justify-center transition-all"
          style={{ backgroundColor: scrolled ? '#f3f4f6' : 'rgba(255,255,255,0.15)', color: scrolled ? C.navy : 'white' }}
          onClick={() => setOpen(!open)}>
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-white border-t border-gray-100 px-6 py-4 space-y-1">
          {links.map(l => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}
              className="block px-4 py-3 rounded-xl text-sm font-semibold hover:bg-gray-50 transition-all"
              style={{ color: C.navy }}>
              {l.label}
            </a>
          ))}
          <button onClick={() => { onWaterRequest(); setOpen(false); }}
            className="flex items-center gap-2 text-white text-sm font-bold px-4 py-3 rounded-xl mt-2 w-full justify-center"
            style={{ backgroundColor: C.gold }}>
            <Droplets size={15} />طلب تزويد بالماء
          </button>
          <Link to="/dashboard"
            className="flex items-center gap-2 text-white text-sm font-bold px-4 py-3 rounded-xl mt-2"
            style={{ backgroundColor: C.teal }}>
            <BarChart3 size={15} />لوحة التحكم
          </Link>
        </div>
      )}
    </header>
  );
}

/* ════════════════════════════════════════
   HERO
════════════════════════════════════════ */
function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{ background: 'linear-gradient(165deg, #05101e 0%, #091926 45%, #0d2236 100%)' }}>

      {/* ── BG: Dot grid ── */}
      <div className="absolute inset-0 pointer-events-none"
        style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

      {/* ── BG: Glow + geometry ── */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Central gold halo */}
        <div className="absolute inset-0"
          style={{ background: 'radial-gradient(ellipse 70% 55% at 50% 42%, rgba(200,151,43,0.10) 0%, transparent 70%)' }} />
        {/* Teal bloom bottom-left */}
        <div className="absolute -bottom-32 -left-32 w-[520px] h-[520px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(27,158,142,0.12) 0%, transparent 65%)', filter: 'blur(60px)' }} />
        {/* Gold bloom top-right */}
        <div className="absolute -top-20 -right-20 w-[400px] h-[400px] rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(200,151,43,0.08) 0%, transparent 65%)', filter: 'blur(50px)' }} />
        {/* Decorative ring outer */}
        <div className="absolute top-1/2 -right-24 w-[580px] h-[580px] rounded-full -translate-y-1/2"
          style={{ border: '1px solid rgba(200,151,43,0.10)' }} />
        {/* Decorative ring inner */}
        <div className="absolute top-1/2 -right-4 w-[420px] h-[420px] rounded-full -translate-y-1/2"
          style={{ border: '1px solid rgba(200,151,43,0.06)' }} />
        {/* Top gold hairline */}
        <div className="absolute top-0 inset-x-0 h-px"
          style={{ background: 'linear-gradient(90deg, transparent 5%, rgba(200,151,43,0.55) 50%, transparent 95%)' }} />
        {/* Bottom vignette */}
        <div className="absolute bottom-0 inset-x-0 h-48"
          style={{ background: 'linear-gradient(to top, #05101e 0%, transparent 100%)' }} />
      </div>

      {/* ── Content ── */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center"
        style={{ paddingTop: '5rem', paddingBottom: '9rem' }}>

        {/* Heritage badge */}
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full mb-10"
          style={{ backgroundColor: 'rgba(200,151,43,0.10)', border: '1px solid rgba(200,151,43,0.28)', color: '#C8972B' }}>
          <Landmark size={12} />
          <span className="text-xs font-bold tracking-widest">أوقاف محمد بن محمد خوجه كوجك — منذ 1163 هـ</span>
        </div>

        {/* Headline */}
        <h1 className="font-black text-white leading-[1.05] mb-6"
          style={{ fontSize: 'clamp(3rem, 7.5vw, 5.5rem)', letterSpacing: '-0.02em' }}>
          ماء طاهر نقي
          <br />
          <span style={{
            background: 'linear-gradient(135deg, #C8972B 0%, #f0c84e 45%, #1B9E8E 100%)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'inline-block',
          }}>من خير الأوقاف</span>
        </h1>

        {/* Rule divider */}
        <div className="flex items-center justify-center gap-4 my-8">
          <div className="h-px w-20" style={{ background: 'linear-gradient(to left, rgba(200,151,43,0.55), transparent)' }} />
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: '#C8972B', opacity: 0.65 }} />
          <div className="h-px w-20" style={{ background: 'linear-gradient(to right, rgba(200,151,43,0.55), transparent)' }} />
        </div>

        <p className="max-w-xl mx-auto mb-10 leading-loose"
          style={{ color: 'rgba(255,255,255,0.48)', fontSize: 'clamp(0.95rem, 1.8vw, 1.1rem)' }}>
          مياه معبأة بأعلى معايير الجودة العالمية <br className="hidden sm:block" /> 
          خدمةً خيريةً خالصة من مصانع الوقف في المملكة العربية السعودية
        </p>

        {/* Cert pills */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 mb-12">
          {['ISO 22000', 'FSSC 22000', 'HACCP'].map(c => (
            <span key={c} className="flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-full"
              style={{ backgroundColor: 'rgba(255,255,255,0.05)', border: '1px solid rgba(200,151,43,0.28)', color: '#C8972B' }}>
              <ShieldCheck size={11} />{c}
            </span>
          ))}
        </div>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#products"
            className="flex items-center gap-2 text-white font-bold px-10 py-4 rounded-2xl transition-all"
            style={{ background: 'linear-gradient(135deg, #C8972B 0%, #a8771e 100%)', boxShadow: '0 4px 28px rgba(200,151,43,0.42)' }}
            onMouseEnter={e => e.currentTarget.style.boxShadow = '0 8px 44px rgba(200,151,43,0.65)'}
            onMouseLeave={e => e.currentTarget.style.boxShadow = '0 4px 28px rgba(200,151,43,0.42)'}>
            <Package size={18} />اكتشف منتجاتنا
          </a>
          <a href="#about"
            className="flex items-center gap-2 font-bold px-10 py-4 rounded-2xl transition-all"
            style={{ color: 'rgba(255,255,255,0.82)', border: '1.5px solid rgba(255,255,255,0.18)', background: 'transparent' }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.07)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.35)'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.18)'; }}>
            عن الوقف
          </a>
        </div>
      </div>

      {/* ── Scroll indicator — cascading chevrons ── */}
      <a href="#about" className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center"
        style={{ textDecoration: 'none' }}>
        <span className="text-xs font-semibold mb-3 tracking-[0.18em]"
          style={{ color: 'rgba(255,255,255,0.25)' }}>استكشف</span>
        <ChevronDown size={20} className="chev-a1" style={{ color: '#C8972B' }} />
        <ChevronDown size={20} className="chev-a2" style={{ color: '#C8972B', marginTop: -10 }} />
        <ChevronDown size={20} className="chev-a3" style={{ color: '#C8972B', marginTop: -10 }} />
      </a>

      <style>{`
        @keyframes chevAnim {
          0%   { opacity: 0.1; transform: translateY(-3px); }
          50%  { opacity: 1;   transform: translateY(3px);  }
          100% { opacity: 0.1; transform: translateY(-3px); }
        }
        .chev-a1 { animation: chevAnim 1.8s ease-in-out infinite; }
        .chev-a2 { animation: chevAnim 1.8s ease-in-out 0.22s infinite; }
        .chev-a3 { animation: chevAnim 1.8s ease-in-out 0.44s infinite; }
      `}</style>
    </section>
  );
}

/* ════════════════════════════════════════
   STATS BAR
════════════════════════════════════════ */
function StatsBar() {
  const stats = [
    { value: '10+', label: 'سنوات من الخبرة',  icon: Calendar  },
    { value: '28+', label: 'جهة مستفيدة',       icon: Heart     },
    { value: '3',   label: 'أحجام منتجات',      icon: Package   },
    { value: '98%', label: 'معدل جودة المنتج',  icon: ShieldCheck },
  ];
  return (
    <section style={{ background: `linear-gradient(90deg, ${C.navy} 0%, #112038 50%, ${C.navy} 100%)`, borderTop: `1px solid rgba(200,151,43,0.15)`, borderBottom: `1px solid rgba(200,151,43,0.15)` }}>
      <div className="max-w-5xl mx-auto px-6 py-8 grid grid-cols-2 md:grid-cols-4 gap-0">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="flex flex-col items-center py-4 px-6 relative"
              style={{ borderRight: i < 3 ? '1px solid rgba(255,255,255,0.07)' : 'none' }}>
              <Icon size={16} className="mb-2" style={{ color: C.gold, opacity: 0.7 }} />
              <p className="font-black text-3xl leading-none mb-1" style={{ color: C.gold, fontVariantNumeric: 'tabular-nums' }}>{s.value}</p>
              <p className="text-xs font-medium" style={{ color: 'rgba(255,255,255,0.45)' }}>{s.label}</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   WATER REQUEST MODAL
════════════════════════════════════════ */
function WaterRequestModal({ open, onClose }) {
  const [form, setForm] = useState({
    name: '', phone: '', entityType: '', entityName: '',
    city: '', qty: '', frequency: '', notes: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleClose = () => {
    setSubmitted(false);
    setForm({ name: '', phone: '', entityType: '', entityName: '', city: '', qty: '', frequency: '', notes: '' });
    onClose();
  };

  if (!open) return null;

  const inputSt = {
    width: '100%', border: '1px solid #e2e8f0', borderRadius: 10, padding: '10px 14px',
    fontSize: 13, fontFamily: "'Cairo','Tajawal',sans-serif", outline: 'none',
  };

  return (
    <>
      <div onClick={handleClose} style={{ position: 'fixed', inset: 0, background: 'rgba(13,21,32,.6)', zIndex: 400, backdropFilter: 'blur(4px)' }} />
      <div style={{
        position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
        zIndex: 401, width: '100%', maxWidth: 560, maxHeight: '92vh',
        background: '#fff', borderRadius: 20, overflow: 'hidden',
        boxShadow: '0 24px 80px rgba(0,0,0,0.3)', display: 'flex', flexDirection: 'column',
        fontFamily: "'Cairo','Tajawal',sans-serif", direction: 'rtl',
      }}>
        {/* Header */}
        <div style={{ padding: '20px 24px 16px', borderBottom: '1px solid #f1f5f9',
          background: `linear-gradient(135deg, ${C.navy} 0%, #0e2435 100%)` }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: `${C.gold}25`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px solid ${C.gold}40` }}>
                <Droplets size={20} color={C.gold} />
              </div>
              <div>
                <h3 style={{ fontSize: 16, fontWeight: 800, color: '#fff', margin: 0 }}>طلب تزويد بالماء</h3>
                <p style={{ fontSize: 11, color: 'rgba(255,255,255,.5)', margin: '2px 0 0' }}>أوقاف محمد بن محمد خوجه كوجك</p>
              </div>
            </div>
            <button onClick={handleClose} style={{ background: 'rgba(255,255,255,.1)', border: 'none',
              width: 32, height: 32, borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <X size={16} color="white" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          {submitted ? (
            <div style={{ textAlign: 'center', padding: '40px 0' }}>
              <div style={{ width: 72, height: 72, borderRadius: '50%', background: '#f0fdf4',
                display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px',
                border: '3px solid #22c55e' }}>
                <Check size={32} color="#22c55e" />
              </div>
              <h3 style={{ fontSize: 20, fontWeight: 800, color: C.navy, marginBottom: 8 }}>تم استلام طلبك!</h3>
              <p style={{ fontSize: 13, color: '#64748b', lineHeight: 1.8 }}>
                شكراً لك. سيقوم فريقنا بمراجعة طلبك والتواصل معك خلال 48 ساعة عمل.
              </p>
              <button onClick={handleClose} style={{
                marginTop: 24, padding: '12px 32px', borderRadius: 12, border: 'none',
                background: C.gold, color: '#fff', fontFamily: "'Cairo','Tajawal',sans-serif",
                fontSize: 14, fontWeight: 700, cursor: 'pointer'
              }}>إغلاق</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div style={{ background: `${C.teal}08`, border: `1px solid ${C.teal}20`,
                borderRadius: 10, padding: '10px 14px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
                <Heart size={14} color={C.teal} />
                <span style={{ fontSize: 12, color: '#475569' }}>هذه الخدمة مقدمة بصفة خيرية من أوقاف خوجه كوجك</span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    اسم مقدم الطلب <span style={{ color: 'red' }}>*</span>
                  </label>
                  <input required value={form.name} onChange={e => set('name', e.target.value)}
                    style={inputSt} placeholder="الاسم الكامل" />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    رقم الجوال <span style={{ color: 'red' }}>*</span>
                  </label>
                  <input required value={form.phone} onChange={e => set('phone', e.target.value)}
                    style={{ ...inputSt, direction: 'ltr' }} placeholder="05XXXXXXXX" />
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                  نوع الجهة <span style={{ color: 'red' }}>*</span>
                </label>
                <select required value={form.entityType} onChange={e => set('entityType', e.target.value)}
                  style={{ ...inputSt, cursor: 'pointer' }}>
                  <option value="">اختر...</option>
                  <option>مسجد</option>
                  <option>مدرسة</option>
                  <option>جمعية خيرية</option>
                  <option>مستشفى / مركز صحي</option>
                  <option>جهة حكومية</option>
                  <option>أفراد / عائلة</option>
                  <option>أخرى</option>
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    اسم الجهة / المسجد
                  </label>
                  <input value={form.entityName} onChange={e => set('entityName', e.target.value)}
                    style={inputSt} placeholder="اسم الجهة" />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    المدينة <span style={{ color: 'red' }}>*</span>
                  </label>
                  <input required value={form.city} onChange={e => set('city', e.target.value)}
                    style={inputSt} placeholder="مكة، جدة، الرياض..." />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    الكمية المطلوبة <span style={{ color: 'red' }}>*</span>
                  </label>
                  <input required value={form.qty} onChange={e => set('qty', e.target.value)}
                    style={inputSt} placeholder="عدد الكراتين / العبوات" />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                    التكرار
                  </label>
                  <select value={form.frequency} onChange={e => set('frequency', e.target.value)}
                    style={{ ...inputSt, cursor: 'pointer' }}>
                    <option value="">اختر...</option>
                    <option>أسبوعي</option>
                    <option>نصف شهري</option>
                    <option>شهري</option>
                    <option>لمرة واحدة</option>
                  </select>
                </div>
              </div>

              <div style={{ marginBottom: 20 }}>
                <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: C.navy, marginBottom: 6 }}>
                  ملاحظات إضافية
                </label>
                <textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={3}
                  style={{ ...inputSt, resize: 'none' }}
                  placeholder="أي تفاصيل إضافية عن الطلب أو موعد التسليم المفضل..." />
              </div>

              <button type="submit" style={{
                width: '100%', padding: '14px', borderRadius: 12, border: 'none',
                background: `linear-gradient(135deg, ${C.gold}, #b8831f)`,
                color: '#fff', fontFamily: "'Cairo','Tajawal',sans-serif",
                fontSize: 15, fontWeight: 800, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}>
                <Send size={16} />
                إرسال الطلب
              </button>
            </form>
          )}
        </div>
      </div>
    </>
  );
}

/* ════════════════════════════════════════
   ABOUT
════════════════════════════════════════ */
function About({ onWaterRequest }) {
  return (
    <section id="about" style={{ backgroundColor: C.cream }} className="py-24">
      <div className="max-w-6xl mx-auto px-6">

        {/* Section title */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-bold"
            style={{ backgroundColor: `${C.gold}12`, color: C.gold }}>
            <Landmark size={14} />تعريف بالوقف والمصنع
          </div>
          <h2 className="font-black text-4xl" style={{ color: C.navy }}>
            أوقاف محمد بن محمد خوجه كوجك
          </h2>
          <p className="text-gray-400 mt-3 max-w-2xl mx-auto text-sm leading-relaxed">
            وقف خيري عريق يجمع بين الإرث الإسلامي العميق والصناعة الحديثة لخدمة أهل مكة المكرمة والمجتمع
          </p>
        </div>

        {/* Two-column: Waqf + Factory */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">

          {/* ── تعريف بالوقف ── */}
          <div className="bg-white rounded-3xl p-8 border border-gray-100"
            style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.06)', borderTop: `4px solid ${C.gold}` }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${C.gold}15` }}>
                <Landmark size={22} style={{ color: C.gold }} />
              </div>
              <div>
                <h3 className="font-black text-xl" style={{ color: C.navy }}>تعريف بالوقف</h3>
                <p className="text-xs text-gray-400">الوقف الخيري العريق</p>
              </div>
            </div>

            <p className="text-gray-600 text-sm leading-relaxed mb-6">
              يُعدّ وقف أوقاف محمد بن محمد خوجه كوجك من أبرز الأوقاف القائمة بمكة المكرمة، وقد أُنشئ عام <strong style={{ color: C.gold }}>1163هـ</strong>، أي منذ ما يقارب <strong style={{ color: C.gold }}>275 عاماً</strong>. يهدف الوقف إلى جعل جزء كبير من إيراداته <strong>سبيل ماء</strong> لأهل مكة المكرمة، فيما يُوزَّع الجزء الآخر على ذوي صاحب الوقف.
            </p>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              بدأ الوقف في أصله بئراً بجوار بيت الله الحرام مع مجموعة من الخادمين لتقديم الخدمة لقاصدي البئر، إضافة إلى مجموعة من المساكن الشعبية التي تُؤجَّر ويُصرَف دخلها على صيانة البئر وأجور العاملين.
            </p>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              مع توسعة الحرم المكي الشريف، تطورت الأنشطة بشكل كبير حتى باتت تشمل توزيع المياه عبر صهاريج كبيرة وعبوات صحة الماء التي تنتشر اليوم في كثير من المساجد والقطاعات الخدمية والحكومية.
            </p>

            {/* Waqf stats */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: Calendar, label: 'سنة التأسيس', val: '1163هـ',       color: C.gold  },
                { icon: Clock,    label: 'عمر الوقف',   val: '275+ عاماً',  color: C.teal  },
                { icon: Heart,    label: 'طابع الوقف',  val: 'خيري',         color: '#ef4444' },
              ].map((s, i) => {
                const Icon = s.icon;
                return (
                  <div key={i} className="text-center p-4 rounded-2xl"
                    style={{ backgroundColor: `${s.color}08`, border: `1px solid ${s.color}20` }}>
                    <Icon size={18} style={{ color: s.color, margin: '0 auto 6px' }} />
                    <p className="font-black text-base" style={{ color: s.color }}>{s.val}</p>
                    <p className="text-gray-400 text-xs mt-1">{s.label}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── تعريف بالمصنع ── */}
          <div className="bg-white rounded-3xl p-8 border border-gray-100"
            style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.06)', borderTop: `4px solid ${C.teal}` }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${C.teal}15` }}>
                <Building2 size={22} style={{ color: C.teal }} />
              </div>
              <div>
                <h3 className="font-black text-xl" style={{ color: C.navy }}>تعريف بالمصنع</h3>
                <p className="text-xs text-gray-400">مصنع مياه الوقف — جبيل الصناعية</p>
              </div>
            </div>

            <p className="text-gray-600 text-sm leading-relaxed mb-6">
              استجابةً للتطور وزيادة الطلب، طوّر الوقف منظومته ليُنشئ <strong>مصنع مياه الوقف</strong> في <strong style={{ color: C.teal }}>جبيل الصناعية</strong>، المنطقة الشرقية، المملكة العربية السعودية. يعتمد المصنع على أحدث تقنيات المعالجة لإنتاج مياه شرب نقية بأعلى معايير الجودة العالمية.
            </p>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              يُزوِّد المصنع المساجد والمدارس والجمعيات الخيرية وذوي الاحتياج بالمياه المعبأة سبيلاً خيرياً، كما يخدم القطاعات التجارية والحكومية وفق معايير جودة صارمة معتمدة دولياً.
            </p>

            {/* Factory stats */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {[
                { label: 'الموقع',            val: 'جبيل الصناعية'      },
                { label: 'خطوط الإنتاج',     val: '3 خطوط متكاملة'     },
                { label: 'الطاقة الإنتاجية', val: '20,000 عبوة / يوم'  },
                { label: 'نظام المعالجة',    val: 'RO + UV + أوزون'     },
              ].map((item, i) => (
                <div key={i} className="rounded-xl p-3" style={{ background: `${C.teal}06`, border: `1px solid ${C.teal}15` }}>
                  <p className="text-xs text-gray-400 mb-1">{item.label}</p>
                  <p className="font-bold text-sm" style={{ color: C.navy }}>{item.val}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl p-3 text-center" style={{ background: `${C.gold}08`, border: `1px solid ${C.gold}20` }}>
              <p className="text-xs text-gray-400 mb-1">الشهادات الدولية المعتمدة</p>
              <p className="font-bold text-sm" style={{ color: C.gold }}>ISO 22000 · FSSC 22000 · HACCP · SFDA</p>
            </div>
          </div>
        </div>

        {/* ── Water Request CTA ── */}
        <div className="rounded-3xl overflow-hidden text-white"
          style={{ background: `linear-gradient(135deg, ${C.navy} 0%, #0e2a40 60%, ${C.teal}40 100%)` }}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-8 p-10">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0"
                style={{ background: `${C.gold}25`, border: `1px solid ${C.gold}40` }}>
                <Droplets size={28} style={{ color: C.gold }} />
              </div>
              <div>
                <h3 className="font-black text-2xl mb-1">هل تحتاج إلى تزويد بالماء؟</h3>
                <p style={{ color: 'rgba(255,255,255,.6)', fontSize: 14 }}>
                  مساجد · مدارس · جمعيات خيرية · مستشفيات · أفراد — نخدمك سبيلاً لوجه الله
                </p>
              </div>
            </div>
            <button onClick={onWaterRequest}
              className="flex items-center gap-3 font-black text-base px-8 py-4 rounded-2xl hover:opacity-90 transition-all flex-shrink-0"
              style={{ background: `linear-gradient(135deg, ${C.gold}, #b8831f)`,
                boxShadow: `0 8px 32px ${C.gold}50`, color: '#fff' }}>
              <Droplets size={20} />
              طلب تزويد بالماء
              <ChevronRight size={18} />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   PRODUCTS
════════════════════════════════════════ */
function Products() {
  const products = [
    { size: '200 مل',  type: 'كوب',         color: C.teal,  uses: ['فنادق', 'مؤتمرات', 'طيران'],             icon: Droplets },
    { size: '330 مل',  type: 'بلاستيك',     color: C.gold,  uses: ['بيع للأفراد', 'مكاتب', 'مدارس'],         icon: Droplets, featured: true },
     { size: '500 لتر',   type: 'بلاستيك',     color: '#8b5cf6', uses: ['مستودعات', 'مصانع', 'مشاريع كبيرة'], icon: Package  },
  ];
  return (
    <section id="products" className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-bold"
            style={{ backgroundColor: `${C.gold}12`, color: C.gold }}>
            <Package size={14} />تشكيلة منتجاتنا
          </div>
          <h2 className="font-black text-4xl" style={{ color: C.navy }}>منتجاتنا</h2>
          <p className="text-gray-400 mt-4">أربعة أحجام تلبي كل احتياجاتك</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p, i) => {
            const Icon = p.icon;
            return (
              <div key={i}
                className="rounded-3xl border overflow-hidden transition-all hover:-translate-y-1 relative"
                style={{
                  borderColor: p.featured ? C.gold : '#f3f4f6',
                  boxShadow: p.featured ? `0 8px 32px ${C.gold}20` : '0 2px 8px rgba(0,0,0,0.04)',
                }}>
                {p.featured && (
                  <div className="absolute top-4 left-4 flex items-center gap-1 px-2 py-1 rounded-full text-xs font-black text-white"
                    style={{ backgroundColor: C.gold }}>
                    <Star size={10} />الأكثر طلباً
                  </div>
                )}
                <div className="p-8 text-center"
                  style={{ background: `linear-gradient(160deg, ${p.color}08 0%, transparent 60%)` }}>
                  <div className="w-20 h-20 rounded-2xl mx-auto mb-6 flex items-center justify-center"
                    style={{ backgroundColor: `${p.color}12` }}>
                    <Icon size={36} style={{ color: p.color }} />
                  </div>
                  <p className="font-black text-3xl mb-1" style={{ color: p.color }}>{p.size}</p>
                  <p className="text-gray-400 text-sm mb-6">{p.type}</p>
                  <ul className="space-y-2 text-right">
                    {p.uses.map((u, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-gray-500">
                        <Check size={14} style={{ color: p.color }} className="flex-shrink-0" />
                        {u}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="px-6 pb-6">
                  <a href="#contact"
                    className="block w-full text-center font-bold text-sm py-3 rounded-xl transition-all hover:opacity-90"
                    style={{
                      backgroundColor: p.featured ? C.gold : `${p.color}12`,
                      color: p.featured ? 'white' : p.color,
                    }}>
                    طلب عرض سعر
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   QUALITY
════════════════════════════════════════ */
function Quality() {
  const steps = [
    { num: '1', title: 'مصدر المياه',       desc: 'مياه جوفية مختارة تخضع لفحص دوري مستمر',          icon: Droplets,    color: C.teal   },
    { num: '2', title: 'معالجة RO',         desc: 'تصفية عكسية متعددة المراحل لإزالة الشوائب',         icon: Zap,         color: C.gold   },
    { num: '3', title: 'تعقيم بالأوزون',   desc: 'حقن الأوزون والأشعة فوق البنفسجية للقضاء على البكتيريا', icon: ShieldCheck, color: C.navy   },
    { num: '4', title: 'فحص المختبر',      desc: 'تحاليل شاملة قبل الإفراج وفق معايير WHO وSFDA',    icon: FlaskConical,color: '#8b5cf6' },
  ];
  const certs = ['ISO 22000:2018', 'FSSC 22000', 'HACCP', 'هيئة الغذاء والدواء (SFDA)', 'سياسة حلال'];
  return (
    <section id="quality" style={{ backgroundColor: C.cream }} className="py-24">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-bold"
            style={{ backgroundColor: `${C.teal}12`, color: C.teal }}>
            <ShieldCheck size={14} />معايير الجودة
          </div>
          <h2 className="font-black text-4xl" style={{ color: C.navy }}>نظام الجودة والسلامة</h2>
          <p className="text-gray-400 mt-4 max-w-xl mx-auto">كل قطرة تمر بأربع مراحل صارمة قبل وصولها إليك</p>
        </div>

        {/* Process */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {steps.map((s, i) => {
            const Icon = s.icon;
            const isLast = i === steps.length - 1;
            return (
              <div key={i} className="relative">
                <div className="bg-white rounded-2xl p-6 border border-gray-100"
                  style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${s.color}12` }}>
                      <Icon size={18} style={{ color: s.color }} />
                    </div>
                    <span className="font-black text-2xl" style={{ color: `${s.color}40` }}>المرحلة {s.num}</span>
                  </div>
                  <h3 className="font-black text-sm mb-2" style={{ color: C.navy }}>{s.title}</h3>
                  <p className="text-gray-400 text-xs leading-relaxed">{s.desc}</p>
                </div>
                {!isLast && (
                  <div className="hidden lg:flex absolute -left-3 top-1/2 -translate-y-1/2 w-6 items-center justify-center z-10">
                    <ArrowLeft size={16} className="text-gray-300" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Certifications */}
        <div className="bg-white rounded-3xl p-8 border border-gray-100"
          style={{ boxShadow: '0 4px 16px rgba(0,0,0,0.04)' }}>
          <h3 className="font-black text-center text-lg mb-6" style={{ color: C.navy }}>شهاداتنا المعتمدة</h3>
          <div className="flex flex-wrap justify-center gap-3">
            {certs.map((c, i) => (
              <span key={i}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold border"
                style={{ borderColor: `${C.gold}30`, backgroundColor: `${C.gold}06`, color: C.navy }}>
                <Award size={14} style={{ color: C.gold }} />
                {c}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   CTA / ORDER
════════════════════════════════════════ */
function OrderSection() {
  return (
    <section className="py-24" style={{ background: `linear-gradient(135deg, ${C.navy} 0%, #0e2435 100%)` }}>
      <div className="max-w-3xl mx-auto px-6 text-center">
        <div className="w-16 h-16 rounded-2xl mx-auto mb-6 flex items-center justify-center"
          style={{ background: `linear-gradient(135deg, ${C.gold}30, ${C.gold}10)`, border: `1px solid ${C.gold}30` }}>
          <Droplets size={28} style={{ color: C.gold }} />
        </div>
        <h2 className="font-black text-4xl text-white mb-4">هل تريد طلب مياه الوقف؟</h2>
        <p className="text-white/50 text-lg mb-10">نصلك أينما كنت — أفراد، مؤسسات، جهات خيرية</p>
        <form className="bg-white/5 border border-white/10 rounded-3xl p-8 text-right space-y-4"
          onSubmit={e => e.preventDefault()}>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-white/50 text-xs font-semibold block mb-2">الاسم</label>
              <input className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-white/30 transition-all"
                placeholder="اسمك الكريم" />
            </div>
            <div>
              <label className="text-white/50 text-xs font-semibold block mb-2">رقم الجوال</label>
              <input className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-white/30 transition-all"
                placeholder="+966 5X XXXX XXXX" dir="ltr" />
            </div>
          </div>
          <div>
            <label className="text-white/50 text-xs font-semibold block mb-2">المنتج المطلوب</label>
            <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none">
              <option value="" style={{ color: C.navy }}>اختر الحجم</option>
              <option value="200" style={{ color: C.navy }}>200 مل — كوب</option>
              <option value="500" style={{ color: C.navy }}>330 مل</option> 
              <option value="5000" style={{ color: C.navy }}>500 لتر</option>
            </select>
          </div>
          <div>
            <label className="text-white/50 text-xs font-semibold block mb-2">تفاصيل الطلب</label>
            <textarea rows={3}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-white/30 transition-all resize-none"
              placeholder="الكميات، موعد التسليم، ملاحظات..." />
          </div>
          <button type="submit"
            className="w-full text-white font-black py-4 rounded-xl transition-all hover:opacity-90 text-sm"
            style={{ background: `linear-gradient(135deg, ${C.gold}, #b8831f)` }}>
            إرسال الطلب
          </button>
        </form>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   CONTACT
════════════════════════════════════════ */
function Contact() {
  const contacts = [
    { icon: Phone,  label: 'الهاتف',   val: '+966 XX XXX XXXX'   },
    { icon: Mail,   label: 'البريد',   val: 'info@akoya-koshak.sa' },
    { icon: MapPin, label: 'العنوان', val: 'جبيل الصناعية، المنطقة الشرقية، المملكة العربية السعودية' },
  ];
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-4 text-sm font-bold"
            style={{ backgroundColor: `${C.gold}12`, color: C.gold }}>
            <Phone size={14} />اتصل بنا
          </div>
          <h2 className="font-black text-4xl" style={{ color: C.navy }}>تواصل معنا</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {contacts.map((c, i) => {
            const Icon = c.icon;
            return (
              <div key={i} className="text-center p-8 rounded-3xl border border-gray-100 hover:border-gray-200 transition-all"
                style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
                <div className="w-12 h-12 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                  style={{ backgroundColor: `${C.teal}12` }}>
                  <Icon size={22} style={{ color: C.teal }} />
                </div>
                <p className="text-gray-400 text-xs font-semibold mb-2">{c.label}</p>
                <p className="font-bold text-sm" style={{ color: C.navy }}>{c.val}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ════════════════════════════════════════
   FOOTER
════════════════════════════════════════ */
function Footer() {
  return (
    <footer style={{ background: C.dark, color: 'rgba(255,255,255,0.4)' }} className="py-10">
      <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <Logo height={44} />
        <div className="text-center text-sm">
          <p className="font-bold text-white/60 mb-1">أوقاف محمد محمد خوجه كوجك</p>
          <p className="text-xs">جميع الحقوق محفوظة © {new Date().getFullYear()} — أوقاف خوجه كوجك</p>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/dashboard"
            className="flex items-center gap-2 text-white/60 hover:text-white text-xs font-semibold px-3 py-2 rounded-xl border border-white/10 hover:border-white/20 transition-all">
            <BarChart3 size={13} />لوحة التحكم
          </Link>
          <Link to="/erp"
            className="flex items-center gap-2 text-white/60 hover:text-white text-xs font-semibold px-3 py-2 rounded-xl border border-white/10 hover:border-white/20 transition-all">
            <Factory size={13} />نظام ERP
          </Link>
          <Link to="/distribution"
            className="flex items-center gap-2 text-white/60 hover:text-white text-xs font-semibold px-3 py-2 rounded-xl border border-white/10 hover:border-white/20 transition-all">
            <Truck size={13} />التوزيع
          </Link>
        </div>
      </div>
    </footer>
  );
}

/* ════════════════════════════════════════
   PAGE ROOT
════════════════════════════════════════ */
export default function Website() {
  const [waterModal, setWaterModal] = useState(false);
  return (
    <>
      <WaterRequestModal open={waterModal} onClose={() => setWaterModal(false)} />
      <div className="min-h-screen" style={{ direction: 'rtl', fontFamily: 'Cairo, sans-serif' }}>
        <Navbar onWaterRequest={() => setWaterModal(true)} />
        <Hero />
        <StatsBar />
        <About onWaterRequest={() => setWaterModal(true)} />
        <Products />
        <Quality />
        <OrderSection />
        <Contact />
        <Footer />
      </div>
    </>
  );
}
